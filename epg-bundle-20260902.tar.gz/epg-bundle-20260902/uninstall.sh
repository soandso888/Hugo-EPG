#!/usr/bin/env bash
# ============================================================
# myTV SUPER EPG 一键卸载 (目标机器执行, 需 root)
# 用法: sudo bash uninstall.sh          # 交互式确认后卸载
#       sudo bash uninstall.sh -y       # 跳过确认, 直接卸载
#       sudo bash uninstall.sh --keep-data   # 保留 /opt/epg/data 归档数据
# ============================================================
set -euo pipefail

# ---------- 参数解析 ----------
KEEP_DATA=0
ASSUME_YES=0
for a in "$@"; do
  case "$a" in
    -y|--yes) ASSUME_YES=1 ;;
    --keep-data) KEEP_DATA=1 ;;
    *) echo "未知参数: $a (支持 -y 和 --keep-data)" >&2; exit 1 ;;
  esac
done

if [ "$(id -u)" -ne 0 ]; then echo "错误: 请用 root 运行 (sudo bash uninstall.sh)"; exit 1; fi

echo "======================================"
echo "  myTV SUPER EPG 卸载"
echo "======================================"
echo "将移除:"
echo "  - systemd 服务 epg-server.service"
echo "  - 定时归档 cron 任务 (epg_archive.sh)"
echo "  - 目录 /opt/epg"
[ "$KEEP_DATA" = "1" ] && echo "  - (保留 /opt/epg/data 归档数据)" || echo "  - 含 /opt/epg/data 归档数据 (全部删除)"
echo ""

if [ "$ASSUME_YES" != "1" ]; then
  read -r -p "确认卸载? [y/N]: " ans
  case "${ans,,}" in
    y|yes) : ;;
    *) echo "已取消"; exit 0 ;;
  esac
fi

# ---------- 1) 停止并删除 systemd 服务 ----------
echo "== 停止服务 =="
if systemctl list-unit-files | grep -q '^epg-server.service'; then
  systemctl stop epg-server.service 2>/dev/null || true
  systemctl disable epg-server.service 2>/dev/null || true
  rm -f /etc/systemd/system/epg-server.service
  systemctl daemon-reload
  echo "  ok  已删除 epg-server.service"
else
  echo "  --  未安装 systemd 服务, 跳过"
fi

# ---------- 2) 删除 cron 归档任务 ----------
echo "== 清理 cron =="
if crontab -l 2>/dev/null | grep -q 'epg_archive.sh'; then
  crontab -l 2>/dev/null | grep -v 'epg_archive.sh' | crontab - || true
  echo "  ok  已删除归档 cron"
else
  echo "  --  无归档 cron, 跳过"
fi

# ---------- 3) 删除 /opt/epg ----------
echo "== 清理目录 =="
if [ -d /opt/epg ]; then
  if [ "$KEEP_DATA" = "1" ]; then
    mkdir -p /tmp/epg-data-backup
    cp -a /opt/epg/data /tmp/epg-data-backup/ 2>/dev/null || true
    echo "  ok  归档数据已备份到 /tmp/epg-data-backup/"
  fi
  rm -rf /opt/epg
  echo "  ok  已删除 /opt/epg"
else
  echo "  --  /opt/epg 不存在, 跳过"
fi

echo ""
echo "✅ 卸载完成"
if [ "$KEEP_DATA" = "1" ]; then
  echo "   归档数据备份位置: /tmp/epg-data-backup/data (如需恢复: cp -a /tmp/epg-data-backup/data /opt/epg/)"
fi
echo "   提示: 若部署时在防火墙/安全组放行了端口 (如 8765/tcp), 请记得移除"

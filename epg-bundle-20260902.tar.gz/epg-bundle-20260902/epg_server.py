#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""本地 EPG 网页查询: 选频道+日期 -> 节目单时间表 (纯标准库, 零依赖)
运行在 142.91.102.208, 端口 8765"""
import os, re, datetime, html, base64, json, urllib.request
from datetime import timezone, timedelta
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

DATA = '/opt/epg/data'
PORT = 8765

# ---- TLS (可选, 部署向导选择是否启用; True 时用自签证书走 HTTPS) ----
TLS_ENABLED = False
TLS_CERT = '/opt/epg/certs/server.crt'
TLS_KEY = '/opt/epg/certs/server.key'

# ---- Basic Auth ----
AUTH_USER = 'admin'
AUTH_PASS = 'hugo2026+'

# ---- 时区: XMLTV 为 UTC(+0000), 展示转 UTC+8 ----
TZ8 = timezone(timedelta(hours=8))

CHANNELS = [('Jade.hk@SD', '翡翠台'), ('J2.hk@SD', 'J2'), ('Pearl.hk@SD', '明珠台')]
# ---- 实时 API 频道映射 (network_code -> 显示名) ----
API_NETWORKS = [('J', '翡翠台'), ('B', 'J2'), ('P', '明珠台')]
API_URL = 'https://content-api.mytvsuper.com/v1/epg'

def strip_tags(s):
    return re.sub(r'<[^>]+>', '', s).strip()

def load_day(date_str):
    path = os.path.join(DATA, date_str + '.xml')
    if not os.path.exists(path):
        return []
    with open(path, encoding='utf-8') as f:
        raw = f.read()
    out = []
    for m in re.finditer(r'<programme\b[^>]*>(.*?)</programme>', raw, re.S):
        body = m.group(0)
        c = re.search(r'channel="([^"]+)"', body)
        s = re.search(r'start="(\d{8}\d{6})', body)
        st = re.search(r'stop="(\d{8}\d{6})', body)
        inner = m.group(1)
        if c and s and st:
            out.append((c.group(1), s.group(1), st.group(1), inner))
    return out

def fmt(ts):
    """'YYYYMMDDHHMMSS'(UTC) -> 'HH:MM'(UTC+8)"""
    try:
        dt = datetime.datetime.strptime(ts, '%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)
        return dt.astimezone(TZ8).strftime('%H:%M')
    except Exception:
        return ts[8:10] + ':' + ts[10:12]

def fetch_api_epg(networks, from_d, to_d):
    """代理请求官方 API, 整理为前端友好 JSON (不落盘)
    networks: ['J','B','P']  from_d/to_d: 'YYYYMMDD'"""
    url = (f"{API_URL}?platform=web&country_code=HK"
           f"&network_code={','.join(networks)}&from={from_d}&to={to_d}")
    req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0',
                                               'Accept': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            raw = json.loads(r.read().decode('utf-8', 'replace'))
    except Exception as e:
        return {'error': str(e)}

    name_map = dict(API_NETWORKS)
    out = []
    for net in raw:
        code = net.get('network_code', '')
        for item in net.get('item', []):
            date_str = item.get('date', '')
            epg = item.get('epg', [])
            # 计算结束时间: 下一条 start 即本条 stop; 最后一条未知
            progs = []
            for i, p in enumerate(epg):
                start = p.get('start_datetime', '')  # 'YYYY-MM-DD HH:MM:SS'
                stop = epg[i + 1].get('start_datetime', '') if i + 1 < len(epg) else ''
                progs.append({
                    'start': start,
                    'stop': stop,
                    'title': p.get('programme_title_tc', '') or p.get('programme_title_en', ''),
                    'title_en': p.get('programme_title_en', ''),
                    'desc': p.get('episode_synopsis_tc', '') or p.get('episode_synopsis_en', ''),
                    'ep': p.get('episode_no', ''),
                })
            out.append({
                'network': code,
                'name': name_map.get(code, code),
                'date': date_str,
                'progs': progs,
            })
    return {'data': out}

def render(date_str, ch, kw):
    """本地归档 XML 查询页"""
    progs = load_day(date_str)
    if ch:
        progs = [p for p in progs if p[0] == ch]
    if kw:
        progs = [p for p in progs if kw in strip_tags(p[3]).lower()]
    progs.sort(key=lambda p: p[1])
    rows = "".join(
        f"<tr><td>{fmt(p[1])}-{fmt(p[2])}</td><td>{html.escape(strip_tags(p[3]))}</td></tr>"
        for p in progs)
    opts = "".join(f"<option value='{i}' {'selected' if i==ch else ''}>{n}</option>" for i, n in CHANNELS)
    stats = f"{len(progs)} 条节目"
    return HTML.replace("{{date}}", date_str).replace("{{opts}}", opts).replace("{{rows}}", rows).replace("{{kw}}", html.escape(kw)).replace("{{stats}}", stats)

def render_live(from_d, to_d, nets, kw):
    """实时查询页: 表单 + JS 调用 /api/epg"""
    date_today = datetime.date.today().isoformat()
    from_val = from_d if from_d else date_today
    to_val = to_d if to_d else date_today
    checks = "".join(
        f"<label><input type=checkbox name=net value='{c}' {'checked' if c in nets else ''}> {n}</label>"
        for c, n in API_NETWORKS)
    return LIVE_HTML.replace("{{from_val}}", from_val).replace("{{to_val}}", to_val).replace("{{checks}}", checks).replace("{{kw}}", html.escape(kw))



HTML = """<!doctype html><html><meta charset=utf-8><title>myTV SUPER EPG</title>
<style>
 body{font-family:system-ui,'PingFang SC',sans-serif;margin:0;padding:20px;background:#f7f7f7}
 .wrap{max-width:900px;margin:0 auto}
 h2{color:#333}
 form{margin:15px 0;display:flex;gap:8px;flex-wrap:wrap}
 input,select,button{padding:8px 12px;font-size:14px;border:1px solid #ccc;border-radius:6px}
 button{background:#0070c0;color:#fff;border:none;cursor:pointer}
 table{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08)}
 th,td{border:1px solid #e0e0e0;padding:8px 12px;text-align:left;font-size:14px}
 th{background:#f0f4f8}
 td:first-child{white-space:nowrap;color:#666;font-variant-numeric:tabular-nums}
 tr:nth-child(even){background:#fafafa}
 .stats{color:#888;font-size:13px;margin:8px 0}
</style><body><div class=wrap>
<h2>📺 myTV SUPER 本地 EPG</h2>
<form><input type=date name=date value='{{date}}'>
<select name=ch><option value=''>全部频道</option>{{opts}}</select>
<input name=kw placeholder='标题关键字' value='{{kw}}'>
<button>查询</button></form>
<div class=stats>{{date}} · {{stats}} · 时间均为 UTC+8</div>
<table><tr><th>时间</th><th>节目</th></tr>{{rows}}</table>
</div></body></html>"""

LIVE_HTML = """<!doctype html><html><meta charset=utf-8><title>myTV SUPER EPG 实时查询</title>
<style>
 body{font-family:system-ui,'PingFang SC',sans-serif;margin:0;padding:20px;background:#f7f7f7}
 .wrap{max-width:1000px;margin:0 auto}
 h2{color:#333}
 form{margin:15px 0;display:flex;gap:8px;flex-wrap:wrap;align-items:center}
 input,select,button{padding:8px 12px;font-size:14px;border:1px solid #ccc;border-radius:6px}
 input[type=checkbox]{width:auto}
 label{margin-right:6px;font-size:14px}
 button{background:#0070c0;color:#fff;border:none;cursor:pointer}
 table{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-top:10px}
 th,td{border:1px solid #e0e0e0;padding:8px 12px;text-align:left;font-size:14px;vertical-align:top}
 th{background:#f0f4f8}
 td:first-child{white-space:nowrap;color:#666;font-variant-numeric:tabular-nums}
 tr:nth-child(even){background:#fafafa}
 .ch{border:1px solid #ccc;border-radius:4px;display:inline-block;padding:2px 8px;margin-right:4px;background:#eef3f8;font-weight:600}
 .stats{color:#888;font-size:13px;margin:8px 0}
 .en{color:#888;font-size:12px;margin-top:2px}
 .chcell{white-space:nowrap;min-width:110px;font-weight:600;color:#333}
 .desc{color:#666;font-size:12px;max-width:420px}
 .desc.long{max-height:2.6em;overflow:hidden;position:relative;cursor:pointer;padding-right:56px}
 .desc.long::after{content:'展开 ▼';position:absolute;bottom:0;right:0;background:#fff;color:#0070c0;font-size:11px;padding-left:6px}
 .desc.long.open{max-height:none;overflow:visible;padding-right:0;position:static}
 .desc.long.open::after{position:static;content:' 收起 ▲';background:none;padding:0}
 .err{color:#c00;margin:10px 0}
 a.nav{font-size:13px;color:#0070c0;text-decoration:none;margin-right:12px}
</style><body><div class=wrap>
<h2>📺 myTV SUPER EPG 实时查询 <a class=nav href='/'>本地归档查询 →</a></h2>
<p style='color:#666;font-size:13px'>直接查询官方 API（2023 至今历史数据），不保存本地</p>
<form id=f>
<input type=date name=from value='{{from_val}}'> 至
<input type=date name=to value='{{to_val}}'>
<button type=button onclick="shiftDay(-1)">◀ 前一天</button>
<button type=button onclick="shiftDay(1)">后一天 ▶</button>
<span>{{checks}}</span>
<input name=kw placeholder='标题关键字' value='{{kw}}'>
<button type=submit>查询</button>
</form>
<div class=stats id=stats></div>
<div class=err id=err></div>
<table id=tbl><tr><th>时间</th><th>频道</th><th>节目</th><th>简介</th></tr></table>
<script>
const fm = document.getElementById('f');
const tbl = document.getElementById('tbl');
const stats = document.getElementById('stats');
const err = document.getElementById('err');
async function q(){
  const fd = new FormData(fm);
  const nets = fm.querySelectorAll('input[name=net]:checked');
  if (!nets.length) { err.textContent='请至少选一个频道'; return; }
  const params = new URLSearchParams({
    from: fd.get('from').replace(/-/g,''),
    to: fd.get('to').replace(/-/g,''),
    network: [...nets].map(n=>n.value).join(','),
    kw: fd.get('kw')||''
  });
  err.textContent=''; stats.textContent='加载中...';
  try {
    const resp = await fetch('/api/epg?'+params);
    const j = await resp.json();
    if (j.error) { err.textContent='API 错误: '+j.error; stats.textContent=''; return; }
    let rows='', total=0;
    for (const d of j.data) {
      let dayRows='';
      for (const p of d.progs) {
        const t = p.title||'(无标题)';
        const en = (p.title_en && p.title_en !== p.title) ? '<div class=en>'+esc(p.title_en)+'</div>' : '';
        const desc = p.desc? '<div class=desc'+(p.desc.length>120?' long':'')+' data-full="'+esc(p.desc)+'">'+esc(p.desc.slice(0,120))+(p.desc.length>120?'…':'')+'</div>':'';
        const time = (p.start? p.start.slice(11,16):'') + '-' + (p.stop? p.stop.slice(11,16):'?');
        dayRows += `<tr><td>${time}</td><td class=chcell>${esc(d.name)}</td><td>${esc(t)}${en}${p.ep?' <small>('+esc(p.ep)+')</small>':''}</td><td>${desc}</td></tr>`;
      }
      total += d.progs.length;
      if (dayRows) rows += `<tr><td colspan=4 style='background:#e8f0f7;font-weight:600'>${d.date} · ${esc(d.name)} (${d.progs.length}条)</td></tr>` + dayRows;
    }
    tbl.innerHTML = '<tr><th>时间</th><th>频道</th><th>节目</th><th>简介</th></tr>' + rows;
    stats.textContent = `共 ${total} 条节目`;
  } catch(e) { err.textContent = '请求失败: '+e; stats.textContent=''; }
}
function esc(s){return s.replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));}
document.addEventListener('click', e=>{
  const d = e.target.closest('.desc');
  if (!d || !d.dataset.full) return;
  if (d.classList.contains('open')) {
    d.classList.remove('open');
    d.textContent = d.dataset.full.slice(0,120) + (d.dataset.full.length>120?'…':'');
  } else {
    d.classList.add('open');
    d.textContent = d.dataset.full;
  }
});
function fmtDate(dt){const y=dt.getFullYear(),m=String(dt.getMonth()+1).padStart(2,'0'),day=String(dt.getDate()).padStart(2,'0');return y+'-'+m+'-'+day;}
function shiftDay(n){
  const from = fm.querySelector('input[name=from]');
  const to = fm.querySelector('input[name=to]');
  const f = new Date(from.value + 'T00:00:00');
  const t = new Date(to.value + 'T00:00:00');
  f.setDate(f.getDate() + n);
  t.setDate(t.getDate() + n);
  from.value = fmtDate(f);
  to.value = fmtDate(t);
  q();
}
fm.addEventListener('submit', e=>{e.preventDefault(); q();});
q();
</script>
</div></body></html>"""

class Handler(BaseHTTPRequestHandler):
    def _check_auth(self):
        if not AUTH_USER:
            return True  # 未配置用户名 -> 不启用认证 (公开访问)
        auth = self.headers.get('Authorization', '')
        if not auth.startswith('Basic '):
            return False
        try:
            decoded = base64.b64decode(auth[6:]).decode('utf-8')
            user, _, pwd = decoded.partition(':')
            return user == AUTH_USER and pwd == AUTH_PASS
        except Exception:
            return False

    def _unauthorized(self):
        body = b'401 Unauthorized'
        self.send_response(401)
        self.send_header('WWW-Authenticate', 'Basic realm="EPG"')
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._check_auth():
            self._unauthorized()
            return
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/api/epg":
            nets = q.get("network", ["J"])[0].split(",")
            from_d = q.get("from", [""])[0]
            to_d = q.get("to", [""])[0]
            kw = q.get("kw", [""])[0]
            result = fetch_api_epg(nets, from_d, to_d)
            if 'data' in result and kw:
                for d in result['data']:
                    d['progs'] = [p for p in d['progs'] if kw.lower() in (p['title'] + p['title_en'] + p['desc']).lower()]
            body = json.dumps(result, ensure_ascii=False).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif u.path == "/live":
            from_d = q.get("from", [""])[0]
            to_d = q.get("to", [""])[0]
            nets = q.get("net", ["J", "B", "P"])[0].split(",")
            kw = q.get("kw", [""])[0]
            body = render_live(from_d, to_d, nets, kw).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif u.path == "/":
            date_str = q.get("date", [datetime.date.today().isoformat()])[0]
            ch = q.get("ch", [""])[0]
            kw = q.get("kw", [""])[0].lower()
            body = render(date_str, ch, kw).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404); self.end_headers()
    def log_message(self, *a):
        pass

if __name__ == "__main__":
    httpd = ThreadingHTTPServer(('0.0.0.0', PORT), Handler)
    if TLS_ENABLED:
        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.load_cert_chain(TLS_CERT, TLS_KEY)
        httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)
        print(f"EPG server (HTTPS) on :{PORT}", flush=True)
    else:
        print(f"EPG server (HTTP) on :{PORT}", flush=True)
    httpd.serve_forever()

#!/usr/bin/env bash
# 新加坡机 myTV SUPER EPG 累积归档
# 每天调用 iptv-org/epg 抓取 -> 按播出日期切片追加到 data/YYYY-MM-DD.xml -> 滚动清理
set -u

EPG_DIR=/opt/epg
DATA_DIR=$EPG_DIR/data
CHANNELS=$EPG_DIR/mychannels.xml
LOG=$EPG_DIR/epg_grab.log
DAYS=8                      # 单次抓取天数 (API 上限约 8 天)
KEEP_DAYS=30                # 本地保留 30 天 (满足"至少半月")

mkdir -p "$DATA_DIR"

echo "===== [$(date '+%F %T')] grab start =====" >> "$LOG"

# 1) 抓取到临时文件
cd "$EPG_DIR" || exit 1
npx tsx scripts/commands/epg/grab.ts \
  --channels="$CHANNELS" \
  --days=$DAYS \
  --output=/tmp/guide_tmp.xml >> "$LOG" 2>&1
rc=$?
if [ $rc -ne 0 ] || [ ! -s /tmp/guide_tmp.xml ]; then
  echo "  grab FAILED rc=$rc" >> "$LOG"
  exit 1
fi

# 2) 按播出日期切片追加 (去重: 同频道+start 不重复)
KEEP_DAYS_PY=$KEEP_DAYS python3 - "$DATA_DIR" << 'PYEOF'
import re, os, sys, datetime, glob

DATA = sys.argv[1]
import os as _os
KEEP_DAYS = int(_os.environ.get('KEEP_DAYS_PY', '30'))
raw = open('/tmp/guide_tmp.xml', encoding='utf-8').read()

# 按日期聚合 programme
bydate = {}
for m in re.finditer(r'<programme\b.*?</programme>', raw, re.S):
    prog = m.group(0)
    sm = re.search(r'start="(\d{8})', prog)
    if not sm:
        continue
    bydate.setdefault(sm.group(1), []).append(prog)

added_total = 0
for day, progs in bydate.items():
    path = os.path.join(DATA, f"{day[:4]}-{day[4:6]}-{day[6:]}.xml")
    # 已有节目 key (channel + start)
    def prog_key(p):
        c = re.search(r'channel="([^"]+)"', p)
        s = re.search(r'start="(\d{8}\d{6})', p)
        return (c.group(1) + '|' + s.group(1)) if c and s else None
    seen = set()
    if os.path.exists(path):
        with open(path, encoding='utf-8') as f:
            for old in re.finditer(r'<programme\b.*?</programme>', f.read(), re.S):
                k = prog_key(old.group(0))
                if k:
                    seen.add(k)
    # 新节目
    new = []
    for p in progs:
        k = prog_key(p)
        if k and k not in seen:
            new.append(p)
            seen.add(k)
    if new:
        with open(path, 'a', encoding='utf-8') as f:
            f.write('\n'.join(new) + '\n')
        added_total += len(new)

# 3) 滚动清理过期文件
today = datetime.date.today()
removed = 0
for f in glob.glob(os.path.join(DATA, '20*.xml')):
    name = os.path.basename(f)[:10]
    try:
        d = datetime.date.fromisoformat(name)
        if (today - d).days > KEEP_DAYS:
            os.remove(f)
            removed += 1
    except ValueError:
        pass

print(f"  archive: {len(bydate)} days, +{added_total} new programmes, {removed} old removed")
PYEOF

echo "===== [$(date '+%F %T')] grab done =====" >> "$LOG"
# 清理临时文件
rm -f /tmp/guide_tmp.xml
